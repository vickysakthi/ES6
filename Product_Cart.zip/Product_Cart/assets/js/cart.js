let totalProducts = [];
let totalUsers = [];
fetch("products.json")
  .then(res => res.json())
  .then(data => {
    totalProducts = data.ProductCollection; 
    cartProduct(totalProducts); 
  })


let adminPage = document.getElementById('admin-page')
let container = document.getElementById('products-list');
let usercontainer = document.getElementById('user-list');
let userName = document.getElementById('user-name');
let userId = document.getElementById('user-id');
let productSearch = document.getElementById('product-search')
let userSearch = document.getElementById('user-search');
let adminUserSearch = document.getElementById('admin-user-search');
let adminUserList = document.getElementById('admin-user-list');
let adminProductList = document.getElementById('admin-product-list');


let productsContainer = document.createElement('div')
productsContainer.className = 'row';
container.appendChild(productsContainer);


function UserClick() {
         addUser();
}

function addUser() {
let usernamevalue=userName.value;
let useridvalue=userId.value;

let user = { username: usernamevalue, userid: useridvalue };
totalUsers.push(user);

displayUsers(totalUsers);

userName.value = '';
userId.value = '';
}
function displayUsers(userList){
usercontainer.innerHTML = '';
adminUserList.innerHTML = ''; // Clear admin user list

userList.forEach(user => {
let listUsers = document.createElement('div');
listUsers.innerHTML =`<h6 class="text-secondary text-center">${user.username}</h6>
                           <h6 class="text-secondary text-center">${user.userid}</h6>
                           <button id="add-btn" class="btn btn-warning text-white fw-bold Add">ADD</button>`;
listUsers.className = 'd-flex justify-content-between align-items-baseline border border-2 rounded p-3'
usercontainer.appendChild(listUsers);
});
}

if (userSearch) {
  userSearch.addEventListener('input', () => {
    const searchTerm = userSearch.value.trim().toLowerCase();
    const filteredUsers = totalUsers.filter(user => user.username.toLowerCase().includes(searchTerm) || user.userid.toLowerCase().includes(searchTerm));
    displayUsers(filteredUsers);
  });
} else {
  console.warn('User search element not found.');
}

function cartProduct(listdata) {
  productData(listdata);

  productSearch.addEventListener('input', () => {
      const searchTerm = productSearch.value.trim().toLowerCase();
      const filteredData = totalProducts.filter(product => product.ProductId.toLowerCase().includes(searchTerm));
      productData(filteredData);
  });
}

function productData(listdata) {
  productsContainer.innerHTML = '';
  listdata.forEach(product => {
    const columContainer = document.createElement('div')
    // columContainer.className = ('col-md-3')
    let columProductContainer = document.createElement('div')
    columProductContainer.className ='col-md-3'
    columContainer.innerHTML = `<div class=' p-2 card w-100 h-100 border border-1 border-secondary m-2 rounded fw-bold'>
          <img src='${product.ProductPicUrl}' style="width:40%">
          <p class='fs-4'>${product.ProductId}</p> 
          <p class="fs-5">Category:${product.Category}</p>
          <p class="fs-5">Price:${product.Price} </p>
          <p class="fs-5">Quantity:${product.Quantity}</p>
          </div>`
    productsContainer.appendChild(columProductContainer)
    columProductContainer.appendChild(columContainer);
  });
}






  









