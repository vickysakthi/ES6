let totalProducts = [];
let totalUsers = [];

fetch("products.json")
  .then(res => res.json())
  .then(data => {
    totalProducts = data.ProductCollection;
    cartProduct(totalProducts);
  });

  let mainpage = document.getElementById('main-content')
  let adminPageContent = document.getElementById('admin-page');
let container = document.getElementById('products-list');
let usercontainer = document.getElementById('user-list');
let userName = document.getElementById('user-name');
let userId = document.getElementById('user-id');
let productSearch = document.getElementById('product-search');
let userSearch = document.getElementById('user-search');
let adminUserList = document.getElementById('admin-user-list');
let adminProductList = document.getElementById('admin-product-list');
let transactionPage = document.getElementById('transaction-page');
let transactionProductList = document.getElementById('transaction-product-list');
let transactionUsername = document.getElementById('transaction-username');

let productsContainer = document.createElement('div');
productsContainer.className = 'row';
container.appendChild(productsContainer);

function UserClick() {
  addUser();
}

function addUser() {
  let usernamevalue = userName.value;
  let useridvalue = userId.value;

  let user = { username: usernamevalue, userid: useridvalue };
  totalUsers.push(user);

  displayUsers(totalUsers);

  userName.value = '';
  userId.value = '';
}

function displayUsers(userList) {
  usercontainer.innerHTML = '';
  adminUserList.innerHTML = ''; // Clear admin user list

  userList.forEach(user => {
    let listUsers = document.createElement('div');
    listUsers.className = 'd-flex justify-content-between align-items-baseline border border-2 rounded p-3';
    listUsers.innerHTML = `<h6 class="text-secondary text-center">${user.username}</h6>
                           <h6 class="text-secondary text-center">${user.userid}</h6>
                           <button id="add-btn" class="btn btn-warning text-white fw-bold Add">ADD</button>`;
    usercontainer.appendChild(listUsers);

    let adminUserDiv = document.createElement('div');
    adminUserDiv.innerHTML = `<h6 class="text-secondary">${user.username} (${user.userid})</h6>`;
    adminUserDiv.className = 'border-bottom p-2';
    adminUserList.appendChild(adminUserDiv);
  });
}

if (userSearch) {
  userSearch.addEventListener('input', () => {
    const searchTerm = userSearch.value.trim().toLowerCase();
    const filteredUsers = totalUsers.filter(user => user.username.toLowerCase().includes(searchTerm) || user.userid.toLowerCase().includes(searchTerm));
    displayUsers(filteredUsers);
  });
} else {
  console.warn('User search element not found.');
}

function cartProduct(listdata) {
  productData(listdata);

  if (productSearch) {
    productSearch.addEventListener('input', () => {
      const searchTerm = productSearch.value.trim().toLowerCase();
      const filteredData = totalProducts.filter(product => product.ProductId.toLowerCase().includes(searchTerm));
      productData(filteredData);
    });
  } else {
    console.warn('Product search element not found.');
  }
}

function productData(listdata) {
  productsContainer.innerHTML = '';
  adminProductList.innerHTML = ''; // Clear admin product list

  listdata.forEach(product => {
    const columContainer = document.createElement('div');
    let columProductContainer = document.createElement('div');
    columProductContainer.className = 'col-md-3 mb-3';
    columContainer.innerHTML = `<div class='p-2 card w-100 h-100 border border-1 border-secondary m-2 rounded fw-bold'>
          <img src='${product.ProductPicUrl}' style="width:40%">
          <p class='fs-4'>${product.ProductId}</p> 
          <p class="fs-5">Category: ${product.Category}</p>
          <p class="fs-5">Price: ${product.Price} </p>
          <p class="fs-5">Quantity: ${product.Quantity}</p>
          </div>`;
    productsContainer.appendChild(columProductContainer);
    columProductContainer.appendChild(columContainer);

    let adminProductDiv = document.createElement('div');
    adminProductDiv.innerHTML = `<p>${product.ProductId} - ${product.Category} - ${product.Price}</p>`;
    adminProductDiv.className = 'border-bottom p-2';
    adminProductList.appendChild(adminProductDiv);
  });
}

function showAdminPage() {
    mainpage.style.display = 'none';
    adminPageContent.style.display = 'block';
  }


