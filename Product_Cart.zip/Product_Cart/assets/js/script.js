fetch("assets/products.json")
  .then(res => res.json())
  .then(datas => datas.ProductCollection)
  .then(data => cartProduct(data))

let adminPage = document.getElementById('admin')  

let rowContainer = document.getElementById('products-list');
let userList = document.getElementById('user-list');
let userName = document.getElementById('user-name');
let userId = document.getElementById('user-id');
let productSearch = document.getElementById('product-search')
// let userSearch = document.getElementById('user-search')

let productsRowContainer = document.createElement('div')
productsRowContainer.className = 'row'
rowContainer.appendChild(productsRowContainer)


function UserClick() {
  addUser()
}

function addUser() {
// e.preventDefault();
let usernamevalue=userName.value
let useridvalue=userId.value
let users = document.createElement('div')

users.innerHTML = `<h6 class="text-secondary text-center">${usernamevalue}</h6>
<h6 class="text-secondary text-center">${useridvalue}</h6>
<button id="add-btn" class="btn btn-warning text-white fw-bold Add">ADD</button>`
users.className = 'd-flex justify-content-between align-items-baseline border border-2 rounded p-3'
userList.appendChild(users)
userName.value = '';
userId.value = '';
}

function cartProduct(products) {

  products.forEach(product => {
    // console.log((product.ProductPicUrl));
    let columContainer = document.createElement('div')
    columContainer.className = ('col-md-4')
    let columProductContainer = document.createElement('div')
    columProductContainer.innerHTML = `<div class='card d-flex justify-content-between p-2 fw-bold fs-4'>
          <img src='${product.ProductPicUrl}' style="width:40%">
          <p class='fs-4'>${product.Name}</p> 
          <p class="fs-5">Category:${product.Category}</p>
          <p class="fs-5">Price:${product.Price} </p>
          <p class="fs-5">Quantity:${product.Quantity}</p>
          <button class='btn btn-outline-warning btn-sm ms-2' 
          onclick='addToCart(${product.ProductId})'>Add</button></div>`
    productsRowContainer.appendChild(columContainer)
    columContainer.appendChild(columProductContainer)
  });
}


let userSearch = document.getElementById('user-search');
// let productsRowContainer = document.getElementById('products-row'); // Assuming you have a container element to display filtered products

function filterProducts(filterText) {
  let productFilter = filterText.trim().toLowerCase(); // Use toLowerCase() instead of toLowercase()
  
  products.filter(product => {
    return product.name.toLowerCase().includes(productFilter);
  }).forEach(product => {
    let columContainer = document.createElement('div');
    columContainer.className = 'col-md-4';
    
    let columProductContainer = document.createElement('div');
    columProductContainer.innerHTML = `<div class='card d-flex justify-content-between p-2 fw-bold fs-4'>
          <img src='${product.ProductPicUrl}' style="width:40%">
          <p class='fs-4'>${product.Name}</p> 
          <p class="fs-5">Category: ${product.Category}</p>
          <p class="fs-5">Price: ${product.Price}</p>
          <p class="fs-5">Quantity: ${product.Quantity}</p>
          <button class='btn btn-outline-warning btn-sm ms-2' onclick='addToCart(${product.ProductId})'>Add</button></div>`;
    
    productsRowContainer.appendChild(columContainer);
    columContainer.appendChild(columProductContainer);
  });
}

userSearch.addEventListener('input', function() {
  let searchText = userSearch.value;
  productsRowContainer.innerHTML = '';
  
  if (searchText.trim() !== '') {
    filterProducts(searchText);
  }
});








