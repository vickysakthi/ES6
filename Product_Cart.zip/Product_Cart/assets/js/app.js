let totalProducts = [];
let totalUsers = [];

let mainpage = document.getElementById('main-content')
let adminPageContent = document.getElementById('admin-page');
let container = document.getElementById('products-list');
let usercontainer = document.getElementById('user-list');
let userName = document.getElementById('user-name');
let userId = document.getElementById('user-id');
let productSearch = document.getElementById('product-search');
let userSearch = document.getElementById('user-search');
let adminUserList = document.getElementById('admin-user-list');
let adminProductList = document.getElementById('admin-product-list');
let transactionPage = document.getElementById('transaction-page');
let transactionProductList = document.getElementById('transaction-product-list');
let transactionUsername = document.getElementById('transaction-username');

let productsContainer = document.createElement('div');
productsContainer.className = 'row';
container.appendChild(productsContainer);

fetch("products.json")
  .then(res => res.json())
  .then(data => {
    totalProducts = data.ProductCollection;
    cartProduct(totalProducts);
  })
  // .catch(error => console.error('Error fetching products:', error));


// function UserClick() {
//   addUser();
// }

function addUser() {

  let usernamevalue = userName.value;
  let useridvalue = userId.value;

  if (usernamevalue && useridvalue) {
  let user = { username: usernamevalue, userid: useridvalue };
  totalUsers.push(user);
  displayUsers(totalUsers);

  userName.value = '';
  userId.value = '';
  }else{
    alert('enter username and userid')
  }
}

function displayUsers(userList) {
  usercontainer.innerHTML = '';
  adminUserList.innerHTML = ''; // Clear admin user list

  userList.forEach(user => {
    let listUsers = document.createElement('div');
    listUsers.className = 'd-flex justify-content-between align-items-baseline border border-2 rounded p-3';
    
    listUsers.innerHTML = `
        <h6 class="text-secondary text-center">${user.username}</h6>
      <h6 class="text-secondary text-center">${user.userid}</h6>
      <button class="btn btn-warning text-white fw-bold" onclick="selectUser('${user.username}', '${user.userid}')">ADD</button>
      `;
      usercontainer.appendChild(listUsers);

    let adminUserDiv = document.createElement('div');
    adminUserDiv.innerHTML = `<h6 class="text-secondary">${user.username} (${user.userid})</h6>`;
    adminUserDiv.className = 'border-bottom p-2';
    adminUserList.appendChild(adminUserDiv);
  });
}

if (userSearch) {
  userSearch.addEventListener('input', () => {
    const searchTerm = userSearch.value.trim().toLowerCase();
    const filteredUsers = totalUsers.filter(user => 
      user.username.toLowerCase().includes(searchTerm) || user.userid.toLowerCase().includes(searchTerm)
    );
    displayUsers(filteredUsers);
  });
} else {
  console.warn('User search element not found.');
}

function cartProduct(listdata) {
  productData(listdata);

  if (productSearch) {
    productSearch.addEventListener('input', () => {
      const searchTerm = productSearch.value.trim().toLowerCase();
      const filteredData = totalProducts.filter(product => product.ProductId.toLowerCase().includes(searchTerm));
      productData(filteredData);
    });
  } else {
    console.warn('Product search element not found.');
  }
}

//display data
function productData(listdata) {
  productsContainer.innerHTML = '';
  adminProductList.innerHTML = ''; 

  listdata.forEach(product => {
    // const columContainer = document.createElement('div');
    let columProductContainer = document.createElement('div');
    columProductContainer.className = 'col-md-3 mb-3';
    columProductContainer.innerHTML = `
       <div class="card">
          <input type='checkbox' value='${product.ProductId}'>
          <img src='${product.ProductPicUrl}' class="card-img-top" alt="${product.ProductId}">
          <div class="card-body">
          <h5 class="card-title">${product.ProductId}</h5>
          <p class="card-text">Category: ${product.Category}</p>
          <p class="card-text">Price: ${product.Price}</p>
          <p class="card-text">Quantity: ${product.Quantity}</p>
          <button class="btn btn-warning text-white fw-bold" onclick="selectProduct('${product.ProductId}', '${product.Category}', '${product.Price}', '${product.Quantity}')">ADD</button>
          </div>
          </div>`;
          productsContainer.appendChild(columProductContainer);
    // productsContainer.appendChild(columProductContainer);
    // columProductContainer.appendChild(columContainer);

    let adminProductDiv = document.createElement('div');
    adminProductDiv.innerHTML = `<p>${product.ProductId} - ${product.Category} - ${product.Price}</p>`;
    adminProductDiv.className = 'border-bottom p-2';
    adminProductList.appendChild(adminProductDiv);
  });
}

let selectedUser = null;
let selectedProducts = [];

function selectUser(username, userid) {
  selectedUser = { username, userid };
  navigateToTransactionPage();
}

function selectProduct(ProductId, Category, Price, Quantity) {
  const product = { ProductId, Category, Price, Quantity };
  selectedProducts.push(product);
  navigateToTransactionPage();
}

function navigateToTransactionPage() {
  if (selectedUser && selectedProducts.length > 0) {
    document.getElementById('main').classList.add('d-none');
    transactionPage.classList.remove('d-none');
    transactionUsername.textContent = selectedUser.username;

    const transactionProductList = document.getElementById('transaction-product-list');
    transactionProductList.innerHTML = '';

    selectedProducts.forEach(product => {
      const productItem = document.createElement('div');
      productItem.className = 'd-flex justify-content-between align-items-center border p-2 mb-2';
      productItem.innerHTML = `
        <div>
          <p class="mb-0">${product.ProductId}</p>
          <small class="text-muted">Quantity: <input type="number" value="${product.Quantity}" class="form-control d-inline-block w-25"></small>
        </div>
      `;
      transactionProductList.appendChild(productItem);
    });
  }
}

// Event listener for payment button
document.getElementById('payment-button').addEventListener('click', () => {
  alert('Payment Successful');
  resetTransaction();
});

// Event listener for back button
document.getElementById('back-button').addEventListener('click', () => {
  transactionPage.classList.add('d-none');
  document.getElementById('main').classList.remove('d-none');
  resetTransaction();
});

function resetTransaction() {
  selectedUser = null;
  selectedProducts = [];
}

function showAdminPage() {
    mainpage.style.display = 'none';
    adminPageContent.style.display = 'block';
  }

  const backToMainButton = document.getElementById('back-to-main-button');

if (backToMainButton) {
  backToMainButton.addEventListener('click', () => {
    mainpage.style.display = 'block'; // Show the main page
    adminPageContent.style.display = 'none'; // Hide the admin page
    resetTransaction(); // Reset transaction if needed
  });
} else {
  console.warn('Back to Main button element not found.');
}