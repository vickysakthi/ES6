// Global variable to store the complete product list
let completeProductList = [];

// Fetch products data and initialize product list
fetch('products.json')
    .then(res => res.json())
    .then(data => data.ProductCollection)
    .then(value => {
        completeProductList = value;
        productData(value);
    });

let main = document.getElementById('main');
let nameField = document.getElementById('name-field');
let numberField = document.getElementById('number-field');
let friendList = document.getElementById('card-one');
let productList = document.getElementById('card-two');
let userList = document.getElementById('card-three');
let friendSearch = document.getElementById('friend-list-search');
let productSearch = document.getElementById('product-list-search');
let userSearch = document.getElementById('user-list-search');

let rowDiv = document.createElement('div');
rowDiv.className = "row";
productList.appendChild(rowDiv);

function buttonClick() {
    nameList();
}

function nameList() {
    let nameValue = nameField.value;
    let numberValue = numberField.value;

    let userHead = document.createElement('div');
    userHead.innerHTML = `<h6 class="text-dark text-center">${nameValue}</h6><h6 class="text-dark text-center">${numberValue}</h6>
    <button id="add-btn" class="btn btn-success text-white fw-bold Add">ADD</button>`;
    userHead.className = 'd-flex justify-content-between m-1 align-items-baseline border border-1 border-dark rounded p-3';
    userList.appendChild(userHead);
    nameField.value = '';
    numberField.value = '';

    const addButton = userHead.querySelector('.Add');
    addButton.addEventListener('click', () => {
        userHead.innerHTML = `<h6 class="text-dark text-center">${nameValue}</h6><h6 class=" text-center">${numberValue}</h6>
        <button id="add-btn" class="btn btn-secondary text-white fw-bold Add">Remove</button>`;
        let productDataDisplay = document.createElement('div');
        productDataDisplay.innerHTML = `<h6 class="d-flex justify-content-between align-items-baseline border border-1 border-info rounded p-3">${nameValue}
            <span>${numberValue}</span><span class="btn btn-secondary text-white fw-bold">Remove</span></h6>`;
        friendList.appendChild(productDataDisplay);

        productDataDisplay.querySelector('.btn-secondary').addEventListener('click', () => {
            productDataDisplay.remove();
        });
        userHead.querySelector('.btn-secondary').addEventListener('click', () => {
            userHead.remove();
        });
    });
}

function productData(datalist) {
    renderProductList(datalist);

    productSearch.addEventListener('input', () => {
        const searchTerm = productSearch.value.trim().toLowerCase();
        const filteredData = completeProductList.filter(el => el.ProductId.toLowerCase().includes(searchTerm));
        renderProductList(filteredData);
    });
}

function renderProductList(datalist) {
    rowDiv.innerHTML = ''; // Clear existing products
    datalist.forEach(el => {
        let datas = el.ProductId;
        let img = el.ProductPicUrl;
        let category = el.Category;
        let main = el.MainCategory;
        let tax = el.SupplierName;
        const containers = document.createElement('div');
        let columnDiv = document.createElement('div');
        columnDiv.className = "col-md-3";
        containers.innerHTML = `<div class="text-center p-2 card w-100 h-100 border border-1 border-secondary m-2 rounded fw-bold">
               <img src="${img}" width="100px" height="100px"><h6 class="text-dark"> ${datas}</h6>
               <h6 class="text-dark"> ${category}</h6><h6 class="text-dark"> ${main}</h6><h6 class="text-dark"> ${tax}</h6></div>`;
        rowDiv.appendChild(columnDiv);
        columnDiv.appendChild(containers);
    });
}

function searchFriends() {
    friendSearch.addEventListener('keyup', () => {
        const searchTerm = friendSearch.value.trim().toLowerCase();
        const friendItems = friendList.querySelectorAll('div');
        friendItems.forEach(item => {
            const name = item.querySelector('h6').textContent.toLowerCase();
            if (name.includes(searchTerm)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });
}

function searchUsers() {
    userSearch.addEventListener('input', () => {
        const searchTerm = userSearch.value.trim().toLowerCase();
        const userItems = userList.querySelectorAll('div');
        userItems.forEach(item => {
            const name = item.querySelector('h6').textContent.toLowerCase();
            if (name.includes(searchTerm)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });
}

// Initialize search functions
searchFriends();
searchUsers();